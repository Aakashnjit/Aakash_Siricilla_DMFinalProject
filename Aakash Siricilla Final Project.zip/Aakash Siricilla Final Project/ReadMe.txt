CS634-FinalProject
Classification and evaluating Naive Bayes, Random forest and LSTM using 10fold cross validation
To check how the overall code runs, 
Run Aakash_siricilla_FinaProjectMain.ipynb in jupyter notebook

Please note that printing the output may take longer due to the LSTM model. Kindly anticipate some waiting time.
